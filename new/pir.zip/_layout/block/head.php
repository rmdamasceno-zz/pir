﻿<head>
	<meta charset='<?php echo $sitecharset ?>'>
	<meta name="description" content='<?php echo $sitedescription ?>'>
	<meta name="keywords" content='<?php echo $sitekeywords ?>'>
	<meta name="author" content='<?php echo $siteauthor ?>'>
	<meta name="viewport" content='<?php echo $siteviewport ?>'>
	<title><?php echo $maintitle . $localtitle; ?></title>
    <link rel="stylesheet" type="text/css" href='<?php echo $themepatch . $theme; ?>.css'>
</head>