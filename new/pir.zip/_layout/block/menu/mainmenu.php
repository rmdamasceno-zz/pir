﻿<nav id="nav-principal">
  <ul>
    <li><a href="/">HOME</a></li>
    <li> | </li>
    <li><a href="/_referenciados/">REFERENCIADOS</a></li>
    <li> | </li>
    <li><a href="/_convites/">CONVITES</a></li>
    <li> | </li>
    <li><a href="/_finances/">FINANCEIRO</a></li>
    <li> | </li>
    <li><a href="/_help/">AJUDA</a></li>
  </ul>
</nav>