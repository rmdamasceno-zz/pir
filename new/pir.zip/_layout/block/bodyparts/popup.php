﻿<div id='popup'>
Bem Vindo <?php echo $_SESSION['user']; ?>
</br>Seu acumulado atual é <a href='/_finances'>$ag</a>
</br>Seu seguro está <a href='/_seguro'>$stseg</a>
</br><span id='sair'><a href='/sair'>sair</a>
</div>