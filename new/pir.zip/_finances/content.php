﻿<?php
	$acesslevel="user";
	$readmenu="yes";
	$title = "";
	$mainconent = "pg financeiro</br><a href='http://piramidedocoringa.com/_logon'>LOGON</a>";
?>

