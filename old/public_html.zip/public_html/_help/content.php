﻿<?php
	$acesslevel="user";
	$readmenu="yes";
	$title = "";
	$mainconent = "pg help</br><a href='http://piramidedocoringa.com/_logon'>LOGON</a>";
?>

