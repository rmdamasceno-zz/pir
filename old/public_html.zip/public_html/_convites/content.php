﻿<?php
	$acesslevel="user";
	$readmenu="yes";
	$title = "";
	$mainconent = "pg convites</br><a href='http://piramidedocoringa.com/_logon'>LOGON</a>";
?>

