﻿<?php
$maintitle = "Pirâmide do Coringa";
$maindom = "http://piramidedocoringa.com";
$defaultseparator = " - ";


$sitecharset="UTF-8";
$sitedescription="Pirâmide do Coringa";
$sitekeywords="Pirâmide,Coringa,dinheiro,internet,ganhar";
$siteauthor="Rafael Damasceno";
$siteviewport="width=device-width, initial-scale=1.0";

$themepatch = "/_layout/css/";
$theme="default";

$sitefooter="Pirâmide do Coringa&copy;&reg;" . $defaultseparator . date("Y");

?>