﻿<?php
	$acesslevel="user";
	$readmenu="yes";
	$title = "";
	$mainconent = "teste de conteudo de página</br></br>esta página não possui formatação</br><a href='http://piramidedocoringa.com/_logon'>LOGON</a>";
?>

